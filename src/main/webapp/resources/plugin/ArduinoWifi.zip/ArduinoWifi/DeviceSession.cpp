#include "DeviceSession.hpp"

DeviceSession::DeviceSession(WiFiClient &_client, const char *apiToken, const char *appToken, const char *deviceKey) : client(_client)
{
    this->apiToken = apiToken;
    this->deviceKey = deviceKey;
    this->appToken = appToken;
    this->connected = false;
    this->buffer = NULL;
    this->length = 0;
    this->remaining = 0;
    this->state = 1;
    this->onMessageReceived = NULL;
}

const char *DeviceSession::host = "automation-server.ddns.net";
const uint16_t DeviceSession::port = 9909;

DeviceSession::~DeviceSession()
{

    if (buffer != NULL)
        delete[] buffer;
}

bool DeviceSession::connect()
{
    if (!client.connect(host, port))
        return false;
    authenticate();
    return connected;
}

void DeviceSession::authenticate()
{
    connected = false;
    char *authMsg = new char[40];
    memset(authMsg, 0, 40 * sizeof(char));
    authMsg[3] = 0x24; // fixed value
    authMsg[4] = 0x44; // fixed value
    for (int i = 0; i < 15; i++)
        authMsg[i + 5] = apiToken[i];
    for (int i = 0; i < 15; i++)
        authMsg[i + 20] = appToken[i];
    for (int i = 0; i < 5; i++)
        authMsg[i + 35] = deviceKey[i];
    client.write(authMsg, 40);
    client.flush();

    delete[] authMsg;

    byte count = 0;
    while (!client.available())
    {
        delay(100);
        count++;
        if (count >= 20)
        {
            client.stop();
            return;
        }
    }

    byte x = client.read();
    if (x == 1)
        connected = true;
    else
        client.stop();
}

void DeviceSession::update()
{
    if (!connected)
        return;

    Message *m;
    while (client.available())
    {
        char ch = client.read();
        switch (state)
        {
        case 1:
            length = (ch << 24) & 0xFF000000;
            state++;
            break;
        case 2:
            length |= (ch << 16) & 0x00FF0000;
            state++;
            break;
        case 3:
            length |= (ch << 8) & 0x0000FF00;
            state++;
            break;
        case 4:
            length |= ch & 0x000000FF;
            if (length == 0)
            {
                state = 1;
                break;
            }
            state++;
            buffer = new char[length];
            remaining = length;
            break;
        case 5:
            buffer[length - remaining] = ch;
            remaining--;
            if (remaining == 0)
            {
                state = 1;
                m = new Message(buffer, length);
                if (onMessageReceived != NULL)
                    onMessageReceived(m);
                delete m;
                delete[] buffer;
                buffer = NULL;
            }
        }
    }
}

void DeviceSession::setOnMessageReceived(void (*fct)(Message *))
{
    this->onMessageReceived = fct;
}

void DeviceSession::sendMessage(Message *message)
{
    char *data;
    int length;
    message->toArray(&data, &length);
    char len[4];
    len[0] = (length & 0xFF000000) >> 24;
    len[1] = (length & 0x00FF0000) >> 16;
    len[2] = (length & 0x0000FF00) >> 8;
    len[3] = (length & 0x000000FF);
    client.write(len, 4);
    client.flush();
    client.write(data, length);
    client.flush();
    delete[] data;
}

bool DeviceSession::isConnected()
{
    return connected;
}
