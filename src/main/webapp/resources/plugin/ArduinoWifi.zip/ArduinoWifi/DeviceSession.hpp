#ifndef DEVICE_SESSION_HPP
#define DEVICE_SESSION_HPP

#include <ESP8266WiFi.h>
#include "Message.hpp"

class DeviceSession
{
private:
    static const char *host;
    static const uint16_t port;
    const char *apiToken;
    const char *appToken;
    const char *deviceKey;
    WiFiClient &client;
    char *buffer;
    int length;
    int remaining;
    int state;
    bool connected;
    void (*onMessageReceived)(Message *);
    Message *constructMsg(byte *, int);

public:
    DeviceSession(WiFiClient &, const char *, const char *, const char *);
    ~DeviceSession();
    void authenticate();
    void update();
    void sendMessage(Message *);
    void disconnect();
    bool connect();
    void setOnMessageReceived(void (*fct)(Message *));
    bool isConnected();
};

#endif
