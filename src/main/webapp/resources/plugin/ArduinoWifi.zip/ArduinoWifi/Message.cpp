#include "Message.hpp"

Message::Message(char *buffer, int length)
{
    this->type = buffer[0];
    this->address = buffer + 1;
    this->data = buffer + 6;
    this->dataLength = length - 6;
    initMType(this->type);
    this->copy = false;
}

Message::Message(const Message & m)
{
    this->type = m.type;
    this->mType = m.mType;
    this->dataLength = m.dataLength;
    this->copy = true;
    this->data = new char[this->dataLength];
    this->address = new char[6];
    memcpy(this->address, m.address, 5 * sizeof(char));
    this->address[5]=0;
    memcpy(this->data, m.data, this->dataLength * sizeof(char));
}

Message::Message(const Message * m)
{
    this->type = m->type;
    this->mType = m->mType;
    this->dataLength = m->dataLength;
    this->copy = true;
    this->data = new char[this->dataLength];
    this->address = new char[6];
    memcpy(this->address, m->address, 5 * sizeof(char));
    this->address[5]=0;
    memcpy(this->data, m->data, this->dataLength * sizeof(char));
}

Message::Message(MessageType mType, char *address, char *data, int length, bool copy)
{
    this->mType = mType;
    initType(mType);
    this->copy = copy;
    if (!this->copy)
    {
        this->address = address;
        this->data = data;
    }
    else
    {
        this->address = new char[6];
        for(int i=0; i<5; i++)
            this->address[i] = address[i];
        this->address[5] = 0;
        this->data = new char[length];
        for (int i = 0; i < length; i++)
            this->data[i] = data[i];
    }
    this->dataLength = length;
}

Message::~Message()
{
    if (!copy)
        return;
    delete[] address;
    delete[] data;
}

void Message::initMType(char type)
{
    switch (type)
    {
    case 1:
        this->mType = DATA;
        break;
    case 2:
        this->mType = ECHO;
        break;
    case 3:
        this->mType = BROADCAST;
        break;
    default:
        this->mType = ERROR;
    }
}

void Message::initType(MessageType mType)
{
    switch (mType)
    {
    case DATA:
        this->type = 1;
        break;
    case ECHO:
        this->type = 2;
        break;
    case BROADCAST:
        this->type = 3;
        break;
    case ERROR:
        this->type = 4;
        break;
    default:
        this->type = 1;
    }
}

int Message::getDataLength()
{
    return this->dataLength;
}

char *Message::getData()
{
    return this->data;
}

MessageType Message::getType()
{
    return mType;
}

void Message::toArray(char **data, int *length)
{
    *length = 6 + this->dataLength;
    *data = new char[*length];
    (*data)[0] = type;
    for (int i = 0; i < 5; i++)
        (*data)[i + 1] = address[i];
    for (int i = 0; i < dataLength; i++)
        (*data)[i + 6] = this->data[i];
}
