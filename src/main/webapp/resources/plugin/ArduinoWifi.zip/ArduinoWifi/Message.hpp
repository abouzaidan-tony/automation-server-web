#ifndef MESSAGE_HPP
#define MESSAGE_HPP

#include <ESP8266WiFi.h>

class DeviceSession;

enum MessageType
{
    DATA,
    ECHO,
    BROADCAST,
    ERROR
};

class Message
{
private:
    char *address;
    char *data;
    int dataLength;
    bool copy;
    MessageType mType;
    char type;
    void initType(MessageType);
    void initMType(char);
    Message(char *, int length);
    void toArray(char **, int *);

public:
    Message(MessageType, char *, char *, int, bool = false);
    Message(const Message &);
    Message(const Message *);
    ~Message();
    bool getKeepAlive();
    char *getData();
    MessageType getType();
    int getDataLength();
    char *getAddress(int *);
    friend class DeviceSession;
};

#endif
